export interface Price {
  min: number;
  max: number;
}
